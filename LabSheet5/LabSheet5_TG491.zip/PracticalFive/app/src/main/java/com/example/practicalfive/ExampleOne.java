package com.example.practicalfive;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ExampleOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_one);
    }
}