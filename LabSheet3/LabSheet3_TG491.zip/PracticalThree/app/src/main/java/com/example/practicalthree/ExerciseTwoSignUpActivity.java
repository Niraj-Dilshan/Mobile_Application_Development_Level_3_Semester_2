package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ExerciseTwoSignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_two_sign_up);

        EditText editTextName = findViewById(R.id.editTextNameETS);
        EditText editTextCity = findViewById(R.id.editTextCityETS);
        EditText editTextUserName = findViewById(R.id.editTextUserNameETS);
        EditText editTextPassword = findViewById(R.id.editTextUserPasswordETS);

        Button buttonSignUp = findViewById(R.id.buttonSignUPETS);
        Button buttonBack = findViewById(R.id.buttonBackETS);

        buttonSignUp.setOnClickListener(v -> {
            String name = editTextName.getText().toString();
            String city = editTextCity.getText().toString();
            String userName = editTextUserName.getText().toString();
            String password = editTextPassword.getText().toString();

            if (name.isEmpty()) {
                editTextName.setError("Please enter your name");
            } else if (city.isEmpty()) {
                editTextCity.setError("Please enter your city");
            } else if (userName.isEmpty()) {
                editTextUserName.setError("Please enter your username");
            } else if (password.isEmpty()) {
                editTextPassword.setError("Please enter your password");
            } else {
                SharedPreferences sharedPreferences = getSharedPreferences("ExerciseTwo", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("name", name);
                editor.putString("city", city);
                editor.putString("username", userName);
                editor.putString("password", password);
                editor.apply();
                Toast.makeText(this, "Sign up successful", Toast.LENGTH_SHORT).show();
            }
        });

        buttonBack.setOnClickListener(v -> {
            finish();
        });
    }
}