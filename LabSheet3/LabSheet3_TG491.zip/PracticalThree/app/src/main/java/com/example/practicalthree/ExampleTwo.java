package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class ExampleTwo extends AppCompatActivity {

    private static final String EXAMPLE_TWO_TAG = ExampleTwo.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_two);
        showLog("onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();
        showLog("onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        showLog("onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        showLog("onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        showLog("onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        showLog("onDestroy");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        showLog("onRestart");
    }

    private void showLog(String text) {
        Log.d(EXAMPLE_TWO_TAG, text);
    }
}