package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ExerciseOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_one);

        EditText editTextUserName = findViewById(R.id.editTextUserName);
        EditText editTextPassword = findViewById(R.id.editTextPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(v -> {
            String userName = editTextUserName.getText().toString();
            String password = editTextPassword.getText().toString();
            if (userName.equals("user") && password.equals("root")) {
                Intent intent = new Intent(ExerciseOne.this, ExerciseOneSecondActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(ExerciseOne.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });
    }
}