package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ExerciseOneSecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_one_second);

        EditText editTextNameEO = findViewById(R.id.editTextNameEO);
        EditText editTextIndexNumber = findViewById(R.id.editTextIndexNumber);
        EditText editTextDepartment = findViewById(R.id.editTextDepartment);
        EditText editTextFaculty = findViewById(R.id.editTextFaculty);

        Button ok = findViewById(R.id.buttonOk);

        ok.setOnClickListener(
            view -> {
                String name = editTextNameEO.getText().toString();
                String indexNumber = editTextIndexNumber.getText().toString();
                String department = editTextDepartment.getText().toString();
                String faculty = editTextFaculty.getText().toString();

                Bundle bundle = new Bundle();

                bundle.putString("name", name);
                bundle.putString("indexNumber", indexNumber);
                bundle.putString("department", department);
                bundle.putString("faculty", faculty);

                Intent intent = new Intent(ExerciseOneSecondActivity.this, ExerciseOneThirdActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        );
    }
}