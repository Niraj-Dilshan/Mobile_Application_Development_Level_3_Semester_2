package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class ExerciseTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_two);

        Button buttonLoginET = findViewById(R.id.buttonLoginET);
        Button buttonSignUpET = findViewById(R.id.buttonSignUpET);

        buttonLoginET.setOnClickListener(v -> {
            Intent newIntent = new Intent(this, ExerciseTwoSignInActivity.class);
            startActivity(newIntent);
        });

        buttonSignUpET.setOnClickListener(v -> {
            Intent newIntent = new Intent(this, ExerciseTwoSignUpActivity.class);
            startActivity(newIntent);
        });
    }
}