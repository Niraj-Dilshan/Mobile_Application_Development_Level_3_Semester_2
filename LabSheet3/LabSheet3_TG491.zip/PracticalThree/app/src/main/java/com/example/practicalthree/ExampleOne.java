package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ExampleOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_one);

        EditText editTextName = findViewById(R.id.editTextName);
        EditText editTextAddress = findViewById(R.id.editTextAddress);
        Button buttonSubmit = findViewById(R.id.buttonSubmit);
        Bundle bundle = new Bundle();
        Intent check = new Intent(this, ExampleOneSecondActivity.class);

        buttonSubmit.setOnClickListener(v -> {
            bundle.putString("name", editTextName.getText().toString());
            bundle.putString("address", editTextAddress.getText().toString());
            check.putExtras(bundle);
            startActivity(check);
        });
    }
}