package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ExampleFour extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_four);

        EditText editTextNameEF = findViewById(R.id.editTextNameEF);
        EditText editTextTownEF = findViewById(R.id.editTextTownEF);

        Button buttonRead = findViewById(R.id.buttonRead);
        Button buttonWrite = findViewById(R.id.buttonWrite);

        buttonWrite.setOnClickListener(v -> {
            SharedPreferences data1 = getSharedPreferences("details", MODE_PRIVATE);
            SharedPreferences.Editor editor = data1.edit();
            editor.putString("name", editTextNameEF.getText().toString());
            editor.putString("town", editTextTownEF.getText().toString());
            editor.commit();
            Toast.makeText(this, "Data Stored", Toast.LENGTH_SHORT).show();
        });

        buttonRead.setOnClickListener(v -> {
            SharedPreferences data1 = getSharedPreferences("details", MODE_PRIVATE);
            String name = data1.getString("name", "not found");
            String town = data1.getString("town", "not found");
            Toast.makeText(this, "Name: " + name + "\nTown: " + town, Toast.LENGTH_SHORT).show();
        });
    }
}