package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonExampleOne = findViewById(R.id.buttonExampleOne);
        Button buttonExampleTwo = findViewById(R.id.buttonExampleTwo);
        Button buttonExampleThree = findViewById(R.id.buttonExampleThree);
        Button buttonExampleFour = findViewById(R.id.buttonExampleFour);
        Button buttonExerciseOne = findViewById(R.id.buttonExerciseOne);
        Button buttonExerciseTwo = findViewById(R.id.buttonExerciseTwo);
        Button buttonExerciseThree = findViewById(R.id.buttonExerciseThree);

        buttonExampleOne.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleOne.class);
            startActivity(intent);
        });

        buttonExampleTwo.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleTwo.class);
            startActivity(intent);
        });

        buttonExampleThree.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleThree.class);
            startActivity(intent);
        });

        buttonExampleFour.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleFour.class);
            startActivity(intent);
        });

        buttonExerciseOne.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseOne.class);
            startActivity(intent);
        });

        buttonExerciseTwo.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseThree.class);
            startActivity(intent);
        });

        buttonExerciseThree.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseTwo.class);
            startActivity(intent);
        });
    }
}