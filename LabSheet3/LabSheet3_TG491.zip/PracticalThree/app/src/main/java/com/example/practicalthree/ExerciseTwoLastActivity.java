package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ExerciseTwoLastActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_two_last);

        TextView editTextName = findViewById(R.id.textViewNameETL);
        TextView editTextCity = findViewById(R.id.textViewCityETL);

        SharedPreferences sharedPreferences = getSharedPreferences("ExerciseTwo", MODE_PRIVATE);
        String name = sharedPreferences.getString("name", "");
        String city = sharedPreferences.getString("city", "");

        editTextName.setText(name);
        editTextCity.setText(city);
    }
}