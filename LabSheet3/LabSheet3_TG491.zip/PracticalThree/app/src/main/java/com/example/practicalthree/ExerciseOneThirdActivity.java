package com.example.practicalthree;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ExerciseOneThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_one_third);

        TextView textViewName = findViewById(R.id.textViewNameEO);
        TextView textViewIndexNumber = findViewById(R.id.textViewIndexNumber);
        TextView textViewDepartment = findViewById(R.id.textViewDepartment);
        TextView textViewFaculty = findViewById(R.id.textViewFaculty);

        Bundle bundle = getIntent().getExtras();

        String name = bundle.getString("name");
        String indexNumber = bundle.getString("indexNumber");
        String department = bundle.getString("department");
        String faculty = bundle.getString("faculty");

        textViewName.setText(name);
        textViewIndexNumber.setText(indexNumber);
        textViewDepartment.setText(department);
        textViewFaculty.setText(faculty);
    }
}