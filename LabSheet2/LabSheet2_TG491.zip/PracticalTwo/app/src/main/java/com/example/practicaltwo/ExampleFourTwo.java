package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ExampleFourTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_four_two);

        TextView textViewIName = findViewById(R.id.textViewIName);
        TextView textViewICity = findViewById(R.id.textViewICity);

        String name = getIntent().getStringExtra("NAME");
        String city = getIntent().getStringExtra("CITY");

        textViewIName.setText(name);
        textViewICity.setText(city);
    }
}