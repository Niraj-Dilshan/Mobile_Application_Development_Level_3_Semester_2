package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ExerciseTheree extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_theree);

        Button loginButton = findViewById(R.id.buttonLogin);
        EditText usernameEditText = findViewById(R.id.editTextUserName);
        EditText passwordEditText = findViewById(R.id.editTextPassword);
        TextView statusView = findViewById(R.id.textViewStatus);

        //login button show the status in statusView
        loginButton.setOnClickListener(view -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // For demonstration purposes, let's assume you have some logic to check the login
            boolean isLoginSuccessful = performLogin(username, password);

            if (isLoginSuccessful) {
                statusView.setText("Login Successful");
            } else {
                statusView.setText("Login Failed");
            }
        });

    }

    private boolean performLogin(String username, String password) {
        // Here, you can implement your login logic.
        // This could involve checking against a database, making API requests, etc.
        // For this example, let's just return a hardcoded result.
        return username.equals("admin") && password.equals("admin");
    }
}