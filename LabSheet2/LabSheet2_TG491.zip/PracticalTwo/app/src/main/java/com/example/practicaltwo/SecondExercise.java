package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class SecondExercise extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_exercise);

        Button clearButton = findViewById(R.id.buttonClear);
        Button additionButton = findViewById(R.id.buttonAddition);
        Button subtractionButton = findViewById(R.id.buttonSubtraction);
        Button multiplicationButton = findViewById(R.id.buttonMultiplication);
        Button divisionButton = findViewById(R.id.buttonDivision);
        EditText numberOne = findViewById(R.id.editTextNumberOne);
        EditText numberTwo = findViewById(R.id.editTextNumberTwo);
        EditText calanswer = findViewById(R.id.editTextCalAnswer);

        clearButton.setOnClickListener(v -> {
            numberOne.setText("");
            numberTwo.setText("");
            calanswer.setText("");
        });

        additionButton.setOnClickListener(v -> {
            float num1 = Float.parseFloat(numberOne.getText().toString());
            float num2 = Float.parseFloat(numberTwo.getText().toString());
            float answer = num1 + num2;
            calanswer.setText(String.valueOf(answer));
        });

        subtractionButton.setOnClickListener(v -> {
            float num1 = Float.parseFloat(numberOne.getText().toString());
            float num2 = Float.parseFloat(numberTwo.getText().toString());
            float answer = num1 - num2;
            calanswer.setText(String.valueOf(answer));
        });

        multiplicationButton.setOnClickListener(v -> {
            float num1 = Float.parseFloat(numberOne.getText().toString());
            float num2 = Float.parseFloat(numberTwo.getText().toString());
            float answer = num1 * num2;
            calanswer.setText(String.valueOf(answer));
        });

        divisionButton.setOnClickListener(v -> {
            float num1 = Float.parseFloat(numberOne.getText().toString());
            float num2 = Float.parseFloat(numberTwo.getText().toString());
            float answer = num1 / num2;
            calanswer.setText(String.valueOf(answer));
        });
    }
}