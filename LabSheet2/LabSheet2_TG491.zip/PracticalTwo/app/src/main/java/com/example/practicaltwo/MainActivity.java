package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button exampleOneButton = findViewById(R.id.exampleOneButton);

        Button exampleTwoButton = findViewById(R.id.exampleTwoButton);

        Button exerciseOneButton = findViewById(R.id.exerciseOneButton);

        Button exerciseTwoButton = findViewById(R.id.exerciseTwoButton);

        Button exerciseThreeButton = findViewById(R.id.exerciseThreeButton);

        Button exampleThreeButton = findViewById(R.id.exampleThreeButton);

        Button exampleFourButton = findViewById(R.id.exampleFourButton);

        exampleOneButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleOne.class);
            startActivity(intent);
        });

        exampleTwoButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleTwo.class);
            startActivity(intent);
        });

        exerciseOneButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseOne.class);
            startActivity(intent);
        });

        exerciseTwoButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SecondExercise.class);
            startActivity(intent);
        });

        exerciseThreeButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseTheree.class);
            startActivity(intent);
        });

        exampleThreeButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleThree.class);
            startActivity(intent);
        });

        exampleFourButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleFour.class);
            startActivity(intent);
        });

    }
}