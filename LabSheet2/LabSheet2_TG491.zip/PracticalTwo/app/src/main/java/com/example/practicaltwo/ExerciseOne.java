package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ExerciseOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_one);

        TextView answer = findViewById(R.id.textViewAnswer);
        EditText firstNumber = findViewById(R.id.firstNumber);
        EditText secondNumber = findViewById(R.id.secondNumber);
        Button addNumbers = findViewById(R.id.buttonAdd);

        addNumbers.setOnClickListener(v -> {
            float first = Float.parseFloat(firstNumber.getText().toString());
            float second = Float.parseFloat(secondNumber.getText().toString());
            float sum = first + second;
            answer.setText(String.valueOf(sum));
        });
    }
}