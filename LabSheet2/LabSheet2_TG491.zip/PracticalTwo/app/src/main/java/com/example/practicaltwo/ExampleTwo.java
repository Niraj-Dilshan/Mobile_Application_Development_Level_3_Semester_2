package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ExampleTwo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_two);

        Button showtextButton = findViewById(R.id.showtextButton);

        TextView display = findViewById(R.id.textView2);

        EditText input = findViewById(R.id.userInput);

        showtextButton.setOnClickListener(v -> {
            String text = input.getText().toString();
            display.setText(text);
        });
    }
}