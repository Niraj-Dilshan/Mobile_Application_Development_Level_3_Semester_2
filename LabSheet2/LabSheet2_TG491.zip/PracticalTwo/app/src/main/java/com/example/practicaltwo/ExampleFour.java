package com.example.practicaltwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class ExampleFour extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_four);

        Button button = findViewById(R.id.button2);

        button.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleFourTwo.class);
            intent.putExtra("NAME", "Anne");
            intent.putExtra("CITY", "Galle");
            startActivity(intent);
        });
    }
}