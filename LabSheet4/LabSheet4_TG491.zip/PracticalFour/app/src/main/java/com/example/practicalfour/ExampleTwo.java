package com.example.practicalfour;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ExampleTwo extends AppCompatActivity {

    static final int REQUEST_CODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_two);

        Button buttonEXT = findViewById(R.id.buttonEXT);

        buttonEXT.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExampleTwoSecondActivity.class);
            startActivityForResult(intent, REQUEST_CODE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ( requestCode == REQUEST_CODE ) {
            String massage = data.getStringExtra("massage");
            TextView textViewEXT = findViewById(R.id.textViewEXT);
            textViewEXT.setText(massage);
        }
    }
}