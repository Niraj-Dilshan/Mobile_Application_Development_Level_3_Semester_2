package com.example.practicalfour;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ExerciseThree extends AppCompatActivity {

    static final int REQUEST_CODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_three);

        Button buttonEnter = findViewById(R.id.buttonEnter);

        buttonEnter.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseThreeSecondActivity.class);
            startActivityForResult(intent, REQUEST_CODE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE) {

            if (data != null) {

                String color = data.getStringExtra("color");
                String formattedColor = color.toLowerCase();

                TextView textViewDisplay = findViewById(R.id.textViewDisplay);

                // Get the drawable resource ID dynamically based on the color
                int drawableResourceId = this.getResources().getIdentifier(formattedColor, "drawable", this.getPackageName());

                // Set the drawable to the left of the text
                textViewDisplay.setCompoundDrawablesWithIntrinsicBounds(drawableResourceId, 0, 0, 0);
                textViewDisplay.setCompoundDrawablePadding(10);  // Padding between the image and the text

                textViewDisplay.setText(color);

            }
        }
    }
}