package com.example.practicalfour;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.util.Linkify;
import android.widget.TextView;

public class ExampleThree extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_three);
        TextView textViewET = findViewById(R.id.textViewET);
        textViewET.setText("Android.com is official website for Android.");
        Linkify.addLinks(textViewET, Linkify.WEB_URLS);
    }
}