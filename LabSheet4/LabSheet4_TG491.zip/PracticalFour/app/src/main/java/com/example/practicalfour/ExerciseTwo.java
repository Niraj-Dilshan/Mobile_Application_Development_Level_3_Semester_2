package com.example.practicalfour;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ExerciseTwo extends AppCompatActivity {

    static final int MY_REQUEST_CODE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_two);

        Button buttonEXT = findViewById(R.id.buttonEXTR);

        buttonEXT.setOnClickListener(v -> {
            Intent intent = new Intent(this, ExerciseTwoSecondActivity.class);
            startActivityForResult(intent, MY_REQUEST_CODE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if( MY_REQUEST_CODE == requestCode ){
            double total = data.getDoubleExtra("total", 0);
            TextView textViewEXTD = findViewById(R.id.textViewEXTD);
            textViewEXTD.setText(String.valueOf(total));
        }
    }
}