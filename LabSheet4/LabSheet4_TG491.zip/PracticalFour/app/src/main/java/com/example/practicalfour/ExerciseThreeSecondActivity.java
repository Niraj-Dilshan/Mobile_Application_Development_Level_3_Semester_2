package com.example.practicalfour;

import static com.example.practicalfour.ExerciseThree.REQUEST_CODE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ExerciseThreeSecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_three_second);

        Button buttonView = findViewById(R.id.buttonView);

        EditText editTextUserInput = findViewById(R.id.editTextUserInput);

        buttonView.setOnClickListener(v -> {
            String userInput = editTextUserInput.getText().toString();
            if (userInput.length() > 0) {
                // check if its White, Red, Blue, Green, Black, Purple without considering case sensitivity
                if (userInput.equalsIgnoreCase("white") || userInput.equalsIgnoreCase("red") || userInput.equalsIgnoreCase("blue") || userInput.equalsIgnoreCase("green") || userInput.equalsIgnoreCase("black") || userInput.equalsIgnoreCase("purple")) {
                    Toast.makeText(this, "Correct color code", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
                    intent.putExtra("color", userInput);
                    setResult(REQUEST_CODE, intent);
                    finish();
                } else {
                    Toast.makeText(this, "Please enter a Correct color code", Toast.LENGTH_SHORT).show();
                }
            } else {
                //display error in a toast
                Toast.makeText(this, "Please enter a color code", Toast.LENGTH_SHORT).show();
            }
        });
    }
}