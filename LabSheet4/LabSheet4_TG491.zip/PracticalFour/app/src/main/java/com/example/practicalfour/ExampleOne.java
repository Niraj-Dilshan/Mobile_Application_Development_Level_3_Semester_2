package com.example.practicalfour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class ExampleOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_one);

        Button buttonOGmail = findViewById(R.id.buttonOGmail);

        buttonOGmail.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW,(Uri.parse("https://gmail.com")));
            startActivity(intent);
        });
    }
}