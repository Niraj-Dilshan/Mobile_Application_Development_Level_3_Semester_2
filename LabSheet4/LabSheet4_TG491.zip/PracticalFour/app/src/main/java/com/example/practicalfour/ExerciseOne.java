package com.example.practicalfour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ExerciseOne extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_one);

        Button buttonVisit = findViewById(R.id.buttonVisit);
        EditText editTextUrl = findViewById(R.id.editTextVisitWeb);

        buttonVisit.setOnClickListener(v -> {
            String url = editTextUrl.getText().toString();
            if(!url.startsWith("http://") && !url.startsWith("https://"))
                url = "http://" + url;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });
    }
}