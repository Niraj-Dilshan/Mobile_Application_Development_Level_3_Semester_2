package com.example.practicalfour;

import static com.example.practicalfour.ExampleTwo.REQUEST_CODE;
import static com.example.practicalfour.ExerciseTwo.MY_REQUEST_CODE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ExerciseTwoSecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_two_second);

        EditText editTextApplePrice = findViewById(R.id.editTextApplePrice);
        EditText editTextBananaPrice = findViewById(R.id.editTextBananaPrice);
        EditText editTextOrangePrice = findViewById(R.id.editTextOrangePrice);
        EditText editTextGrapesPrice = findViewById(R.id.editTextGrapesPrice);
        EditText editTextMangoPrice = findViewById(R.id.editTextMangoPrice);

        Button buttonCalculate = findViewById(R.id.buttonCalculate);

        buttonCalculate.setOnClickListener(v -> {
            double applePrice = Double.parseDouble(editTextApplePrice.getText().toString());
            double bananaPrice = Double.parseDouble(editTextBananaPrice.getText().toString());
            double orangePrice = Double.parseDouble(editTextOrangePrice.getText().toString());
            double grapesPrice = Double.parseDouble(editTextGrapesPrice.getText().toString());
            double mangoPrice = Double.parseDouble(editTextMangoPrice.getText().toString());

            double totalPrice = applePrice + bananaPrice + orangePrice + grapesPrice + mangoPrice;

            Intent intent = new Intent();
            intent.putExtra("total", totalPrice);
            setResult(MY_REQUEST_CODE, intent);
            finish();
        });
    }
}