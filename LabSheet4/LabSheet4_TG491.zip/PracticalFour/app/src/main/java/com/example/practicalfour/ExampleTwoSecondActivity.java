package com.example.practicalfour;

import static com.example.practicalfour.ExampleTwo.REQUEST_CODE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ExampleTwoSecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_two_second);

        Button buttonEXTS = findViewById(R.id.buttonEXTS);
        EditText editTextEXTS = findViewById(R.id.editTextEXTS);

        buttonEXTS.setOnClickListener(v -> {
            String massage = editTextEXTS.getText().toString();
            Intent intent = new Intent();
            intent.putExtra("massage", massage);
            setResult(REQUEST_CODE, intent);
            finish();
        });
    }
}